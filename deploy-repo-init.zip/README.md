# Farset Talent Combined Deploy

This repo deploys BOTH plugin and theme on push to `main` or `farsettalent-theme`, or via manual dispatch.

Required repo secrets: EWP_HOST, EWP_USER, EWP_PASS
