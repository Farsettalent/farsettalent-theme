# Farset Talent Combined Deploy

Deploys BOTH plugin and theme from branch `farsettalent-theme`.

## Deployment Paths
- Plugin → /htdocs/wp-content/plugins/farset-talent-suite/
- Theme  → /htdocs/wp-content/themes/farsettalent-theme/

## Required GitHub Secrets
- EWP_HOST
- EWP_USER
- EWP_PASS
